;===============================================================================
; ASPEED Graphics UEFI Driver ReadMe
;===============================================================================
1.Overview:
- ASPEED Graphics UEFI Driver
2.UEFI Driver Release Architecture:
- X64: UEFI 64bits Driver
3.UEFI Driver Release Image Description:

(THE LAST VERISON SUPPORT FROM AST2050 ~ AST2300 is V1.10)

- uefi_2400_396.rom: AST1400/2400, MCLK=396Mhz
- uefi_2400_dp501.rom: AST1400/2400 + DP501, MCLK=396Mhz
- uefi_2400_dvo.rom: AST1400/2400 + DVO, MCLK=396Mhz
- uefi_2400_ite.rom: AST1400/2400 + ITE66121, MCLK=396Mhz
- uefi_2500_800.rom: AST2500/2510/2530, MCLK=800Mhz
- uefi_2500_dp501.rom: AST2500/2510/2530 + DP501, MCLK=800Mhz
- uefi_2500_dvo.rom: AST2500/2510/2530 + DVO, MCLK=800Mhz
- uefi_2500_ite.rom: AST2500/2510/2530 + ITE66121, MCLK=800Mhz
- uefi_2500_r4.rom: AST2500/2510/2530 + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_2600.rom: AST2600 + ASTDP, MCLK=800Mhz

4.Contact Window:
- kuohsiang_chou@aspeedtech.com
- 886.3.575.1185 ext. 8875