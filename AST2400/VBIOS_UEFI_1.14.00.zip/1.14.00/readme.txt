UEFI / VBIOS folders

/*********************************************************************************************/
/*DETAIL BINARY INFORMATION IS RECORDED IN THE Readme.txt FILES THAT ARE PUT IN EVERY FOLDER.*/
/*********************************************************************************************/

UEFI: UEFI (.EFI) binary folder
- Release.txt .EFI file Release history.
- Readme.txt Readme file to explain every binary.
- \AARCH64 ARM64 version (.EFI) format GOP driver.
- \X64 X64 version (.EFI) format GOP driver.

UEFI_ROM: UEFI (.ROM, extension ROM format) binary folder
- Release.txt .ROM file Release history.
- Readme.txt Readme file to explain every binary.
- \AARCH64 ARM64 version (.ROM) format GOP driver.
- \X64 X64 version (.ROM) format GOP driver.

/**********************************************************************************************/
/*NOTE THE AST2700 BINARIES NEED GET FROM UEFI_ROM (.ROM, extension ROM format) binary folder.*/
/**********************************************************************************************/

Please rename the binary sub-filename and update it into BMC FW
Until now, the GOP driver that is contained in the ./fmc_tool/prebuild

Ex. X64 server case
uefi_x64_2700.rom -> (Rename) -> uefi_x64_ast2700.bin -> Copy to ./fmc_tool/prebuild  

Ex. ARM server case
uefi_arm_2700.rom -> (Rename) -> uefi_x64_ast2700.bin -> Copy to ./fmc_tool/prebuild 

VBIOS: Legacy VBIOS ROM binary folder
- Release.txt VBIOS Release ROM history.
- Readme.txt Readme file to explain every binary.
- \ast2500 VBIOS ROM binary for ast2500.
- \ast2500.r4 VBIOS ROM binary for ast2500 with reserved 4MB frame buffer.
- \ast2600 VBIOS ROM binary for ast2600.
- \ast2600.r4 VBIOS ROM binary for ast2600 with reserved 4MB frame buffer.
- \ast2600.vga VBIOS ROM binary for ast2600 without display port support.

VBIOS+UEFI: Legacy VBIOS and UEFI ROM merged binary folder (ASPEED EVB supported)
- Release.txt Merged binary Release history.
- Readme.txt Readme file to explain every binary.
- \X64 X64 version merged format binary.
