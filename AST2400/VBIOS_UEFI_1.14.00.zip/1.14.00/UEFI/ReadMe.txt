;===============================================================================
; ASPEED Graphics UEFI Driver ReadMe
;===============================================================================
1.Overview:
- ASPEED Graphics UEFI GOP Driver

2.UEFI Driver Release Architecture:
- AARCH64	: ARM ARCH64 GOP Driver with signed(Arch: arm)
- X64		: X64 UEFI GOP Driver with signed(Arch: x64)

3.UEFI Driver Release Image Description:
- uefi_(Arch)_2500_800.efi: AST2500/2510/2530, MCLK=800Mhz
- uefi_(Arch)_2500_r4.efi: AST2500/2510/2530 + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_(Arch)_2600.efi: AST2600 + ASTDP + D-sub, MCLK=800Mhz
- uefi_(Arch)_2600_r4.efi: AST2600 + ASTDP + D-sub + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_(Arch)_2600_vga.efi: AST2600 + D-sub , MCLK=800Mhz
- uefi_(Arch)_2700.efi: AST2700 A1 + ASTDP + D-sub, MCLK=800Mhz
- uefi_(Arch)_2700_r4.efi: AST2700 A1 + ASTDP + D-sub + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_(Arch)_2700_vga.efi: AST2700 + D-sub , MCLK=800Mhz

uefi_x64_2700_DCSCM.efi has been removed from this release.
User could obtain it from V1.13.04 release.

4.Contact Window:
- aspeed_vga_support@aspeedtech.com
