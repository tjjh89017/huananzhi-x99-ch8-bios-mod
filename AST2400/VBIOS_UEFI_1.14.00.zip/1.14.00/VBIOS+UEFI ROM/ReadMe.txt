;===============================================================================
; ASPEED Graphics VBIOS + UEFI Driver ReadMe
;===============================================================================
1.Overview:
- ASPEED Graphics VBIOS + UEFI GOP Driver (Expansion ROM format)

2.UEFI Driver Release Architecture:
- X64		: X64 Merge Binary with signed

3.UEFI Driver Release Image Description:
- uefi_2500.rom: AST2500/2510/2530, MCLK=800Mhz
- uefi_2500_r4.rom: AST2500/2510/2530 + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_2600.rom: AST2600 + ASTDP + D-sub, MCLK=800Mhz
- uefi_2600_r4.rom: AST2600 + ASTDP + D-sub + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_2600_vga.rom: AST2600 + D-sub , MCLK=800Mhz

4.Contact Window:
- aspeed_vga_support@aspeedtech.com

