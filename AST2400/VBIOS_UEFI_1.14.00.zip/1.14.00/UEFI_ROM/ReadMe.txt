;===============================================================================
; ASPEED Graphics UEFI Driver ReadMe
;===============================================================================
1.Overview:
- ASPEED Graphics UEFI GOP Driver (Expansion ROM format)

2.UEFI Driver Release Architecture:
- AARCH64	: ARM ARCH64 GOP Driver with signed(Arch: arm)
- X64		: X64 UEFI GOP Driver with signed(Arch: x64)

3.UEFI Driver Release Image Description:
- uefi_(Arch)_2500_800.rom: AST2500/2510/2530, MCLK=800Mhz
- uefi_(Arch)_2500_r4.rom: AST2500/2510/2530 + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_(Arch)_2600.rom: AST2600 + ASTDP + D-sub, MCLK=800Mhz
- uefi_(Arch)_2600_r4.rom: AST2600 + ASTDP + D-sub + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_(Arch)_2600_vga.rom: AST2600 + D-sub , MCLK=800Mhz
- uefi_(Arch)_2700.rom: AST2700 A1 + ASTDP + D-sub, MCLK=800Mhz
- uefi_(Arch)_2700_r4.rom: AST2700 A1 + ASTDP + D-sub + Reserve 4MB Buffer, MCLK=800Mhz
- uefi_(Arch)_2700_vga.rom: AST2700 + D-sub , MCLK=800Mhz

4.Contact Window:
- aspeed_vga_support@aspeedtech.com

