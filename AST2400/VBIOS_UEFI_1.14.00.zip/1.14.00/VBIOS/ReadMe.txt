;===============================================================================
; ASPEED Graphics VBIOS ReadMe
;===============================================================================
01.Update VBIOS Image under DOS
 - flash [updated image file] [old image file]

02.VBIOS Directory Descriptions:
 - AST2500: 	for AST2500/2510/2530
 - AST2500.R4: 	for AST2500/2510/2530 + Reserved 4MB Buffer 
 - AST2600: 	for AST2600 + ASTDP + D-sub
 - AST2600.R4: 	for AST2600 + ASTDP + D-sub + Reserved 4MB Buffer
 - AST2600.vga: for AST2600 + D-sub

03.Contact Window:
 - aspeed_vga_support@aspeedtech.com

